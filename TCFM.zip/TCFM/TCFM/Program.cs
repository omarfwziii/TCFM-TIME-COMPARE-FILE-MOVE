﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Data.Entity;
using TCFM.ARCHIVE_DB;





namespace TCFM
{
    class Program
    {


        public static void Main()
        {

            Timer t = new Timer(TCFMS,null,0, 60000);
            Console.WriteLine("   ____  _      __   ____ ______  _____   __ __        ___    ___   _____   __ __   ____  _   __   ____ \n" +
                                  "  / __/ | | /| / /  /  _//_  __/ / ___/  / // /       / _ |  / _ \\ / ___/  / // /  /  _/ | | / /  / __/\n" +
                                  " _\\ \\   | |/ |/ /  _/ /   / /   / /__   / _  /       / __ | / , _// /__   / _  /  _/ /   | |/ /  / _/  \n" +
                                  "/___/   |__/|__/  /___/  /_/    \\___/  /_//_/       /_/ |_|/_/|_| \\___/  /_//_/  /___/   |___/  /___/  \n");
            Console.ReadLine();

        }



        private static void TCFMS(object o)
        {
             //************************//
            //SMB ARACHIVE INSTRUCTION// 
           //************************//

            //SAFP SAMBA ARCHIVE FOLDER PATH
            var SAMBA_ARCHIVE_FOLDER_PATH = @"d:/ArchiveSystem/SAF/";
            //SAFC SAMVA ARCHIVE FOLDER COUNT
            int SAMBA_ARCHIVE_FOLDER_COUNT = Directory.GetDirectories(SAMBA_ARCHIVE_FOLDER_PATH).Count();
            //SAFC SAMVA ARCHIVE FOLDER TO LIST
            var SAMBA_ARCHIVE_FOLDER_LIST = Directory.GetDirectories(SAMBA_ARCHIVE_FOLDER_PATH).ToList();


            

            

             //**********************************//
            //Windows Archive Folder INSTRUCTION//
           //**********************************//

            //WINDOWS_ARCHIVE_FOLDER_PATH WINDOWS ARCHIVE FOLDER PATH 
            var WINDOWS_ARCHIVE_FOLDER_PATH = @"d:/ArchiveSystem/WAF/";

             //******************************//
            //CHECK CONNECTION TO SMB SERVER//
           //******************************//
            System.Net.Sockets.TcpClient client = new TcpClient();
            try
            {
                client.Connect("10.10.42.6", 22 );
                Console.WriteLine("******************************** \n");
                Console.WriteLine("Connection open, host active \n");
                Console.WriteLine("******************************** \n");

                //***************//
                //TRY EX STATMENT//
                //***************//
                try
                {
                    //**************************************//
                    //MACHINE TIME & MACHINE TIME CONVERTER//
                    //************************************//
                    var MT = DateTime.Now;
                    long MTC = MT.Year * 10000000000 + MT.Month * 100000000 + MT.Day * 1000000 + MT.Hour * 10000 + MT.Minute * 100 + MT.Second;

                     //***********************//
                    //For LOOP FETCHING FILES//
                   //***********************//
                     
                    for (int Mcount = 0; Mcount !=SAMBA_ARCHIVE_FOLDER_COUNT; Mcount++)
                    {
                          //************************************//
                         //SAMBA ARCHIVE FOLDER  SUBFOLDER NAME//
                        //************************************//
                        string SAMAB_ARCHIVE_SUB_FOLDER_NAME = SAMBA_ARCHIVE_FOLDER_LIST[Mcount].Remove(0, SAMBA_ARCHIVE_FOLDER_PATH.Length);

                         //*****************************//
                        //SUB SAMBA ARCHIVE FOLDER PATH//
                       //*****************************//
                        string SAMAB_ARCHIVE_SUB_FOLDER_PATH = SAMBA_ARCHIVE_FOLDER_PATH + SAMAB_ARCHIVE_SUB_FOLDER_NAME + "/";


                        //SPREATOR

                        var SAMAB_ARCHIVE_SUB_FOLDER_COUNT = Directory.GetDirectories(SAMAB_ARCHIVE_SUB_FOLDER_PATH).Count();
                        var SAMAB_ARCHIVE_SUB_FOLDER_LIST = Directory.GetDirectories(SAMAB_ARCHIVE_SUB_FOLDER_PATH).ToList();
                        for(int Scount = 0; Scount !=SAMAB_ARCHIVE_SUB_FOLDER_COUNT; Scount ++)
                        {
                            //name of the folder to DB 
                            string SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME = SAMAB_ARCHIVE_SUB_FOLDER_LIST[Scount].Remove(0, SAMAB_ARCHIVE_SUB_FOLDER_PATH.Length);
                            //path
                            var SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_PATH = SAMAB_ARCHIVE_SUB_FOLDER_PATH + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME;
                            //******************************//
                            //SAMBA ARCHIVE FOLDER SUBFOLDER//
                            //******************************//
                            var SAFST = Directory.GetCreationTime(SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_PATH);

                            //*******************//
                            //FORMULA CALCULATION//
                            //*******************//
                            var SAFSTX15MIN = SAFST.AddMinutes(15);
                            var FTC = SAFSTX15MIN.Year * 10000000000 + SAFSTX15MIN.Month * 100000000 + SAFSTX15MIN.Day * 1000000 + SAFSTX15MIN.Hour * 10000 + SAFSTX15MIN.Minute * 100 + SAFSTX15MIN.Second;
                            //****************//
                            //COMPARE AND MOVE//
                            //****************//

                            if (MTC > FTC)
                            {
                                //leak
                                var DESTENATION_FOLDER = WINDOWS_ARCHIVE_FOLDER_PATH + SAMAB_ARCHIVE_SUB_FOLDER_NAME + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME;
                                Directory.Move(SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_PATH, DESTENATION_FOLDER); //edit  
                                Console.WriteLine("FILE TRANSFER SESSFULY  : " + WINDOWS_ARCHIVE_FOLDER_PATH + SAMAB_ARCHIVE_SUB_FOLDER_NAME + "\n");

                                var DESTENATION_FOLDER_CREATION_DATE = Directory.GetCreationTime(DESTENATION_FOLDER);


                                //SCAN FILES AND PUSH TO THE DATABASE 
                                using (ArchiveSystemEntities AC = new ArchiveSystemEntities())
                                {
                                    var stmt = AC.Archive_Tbl.Where(r => r.FolderName == SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME).Where(r => r.Cat == SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME).Any();
                                    if (!stmt)
                                    {
                                        Archive_Tbl FTB = new Archive_Tbl();
                                        FTB.FolderName = SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME;
                                        FTB.FolderCreationDate = DESTENATION_FOLDER_CREATION_DATE.ToString("dd/M/yyyy");
                                        //Check If files Exists
                                        bool Photo = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "PhotoLive.jpg");
                                        bool NationalIdFront = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "NationalIdFront.jpg");
                                        bool NationalIdBack = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "NationalIdBack.jpg");
                                        bool ResidenceIdFront = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "ResidenceIdFront.jpg");
                                        bool ResidenceIdBack = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME +  "ResidenceIdBack.jpg");
                                        bool Passport = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "Passport.jpg");
                                        bool Contract = File.Exists(DESTENATION_FOLDER + "/" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME + "Contract.jpg");

                                        FTB.PhotoLive = Photo;
                                        FTB.NationalIdFront = NationalIdFront;
                                        FTB.NationalIdBack = NationalIdBack;
                                        FTB.ResidenceIdFront = ResidenceIdFront;
                                        FTB.ResidenceIdBack = ResidenceIdBack;
                                        FTB.Passport = Passport;
                                        FTB.Contract = Contract;
                                        FTB.Cat = SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME;
                                        AC.Archive_Tbl.Add(FTB);
                                        AC.SaveChanges();
                                    }
                                    else
                                    {
                                        Console.WriteLine("******************************** \n");
                                        Console.WriteLine("FILE EXIST IN THE DATABASE");
                                        Console.WriteLine("******************************** \n");
                                    }


                                }


                            }


                            else
                            {
                                Console.WriteLine("******************************** \n");
                                Console.WriteLine("NOT MOVED DOSENT MEET REQUIRMENT FILE :" + SAMAB_ARCHIVE_SUB_FOLDER_TREE_FOLDER_NAME);
                                Console.WriteLine("******************************** \n");
                            }
                            //***********************//
                            //END OF COMPARE AND MOVE//
                            //***********************//

                        }
                        //END OF SPREATOR



                    }


                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex);
                }
                 
            }
            catch (SocketException ex)
            {
                Console.WriteLine("Connection could not be established due to: \n" + ex.Message);
                Console.WriteLine("************************************************************ \n");

            }

            // Display the date/time when this method got called.
            Console.WriteLine("In TimerCallback: " + DateTime.Now);
            // Force a garbage collection to occur for this demo.
            GC.Collect();

        }

    }
}

